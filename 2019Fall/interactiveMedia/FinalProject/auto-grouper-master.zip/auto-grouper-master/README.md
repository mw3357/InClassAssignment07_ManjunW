# Final-Group-Project-for-5003
## Final Project Proposal for 5003 Interactive Media 
## Manjun Wang, Yanning Xia
## Teachers College, Columbia University

### Summary:
Our project intends to assist teachers in facilitating class project grouping management and also help students improve their collaboration and teamwork experience. Students can better select suitable group partners based on their preferences and skills needed through the website that we want to create, while at the same time instructors can create new projects and manage students’ grouping.   
### Inspiration:
Personal experience: When we have group projects in class, we are usually struggling with how to efficiently find our ideal group mates. Moreover, teachers may feel tricky to manage students’ grouping. 
### Wireframe:
https://www.camscanner.com/share/show?encrypt_id=MHg0ZmRiMzFjZQ%3D%3D&sid=C45B1F2E7D464FB3QR7QS9e7

### Design and Technical reference:
https://www.w3schools.com (css, html, javascript guidelines)
https://www.youtube.com/watch?v=DLX62G4lc44  (react javascript)

### Process:
We have drawn a design sketch on paper about what the website will look like and what features will it have. 
We plan to make a prototype of the main page first. 


 




